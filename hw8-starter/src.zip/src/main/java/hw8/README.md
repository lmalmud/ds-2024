# Homework 8

## Discussion 
In terms of space efficiency, I had to determine whether or not I wanted to
maintain separate maps for incoming and outgoing edges. If I only maintained a map of vertices to all
of their edges, each time I wanted to access an edge, I would have to perform a linear searh. 
