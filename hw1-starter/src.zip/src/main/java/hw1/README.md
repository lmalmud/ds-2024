# Homework 1 Discussion

You don't have any "discussion" questions for this homework! 
However, you will get a few of these for each homework. 
This file is where you are expected to write your answer to those questions.